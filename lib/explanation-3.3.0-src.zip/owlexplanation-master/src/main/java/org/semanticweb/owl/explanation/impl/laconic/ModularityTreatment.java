package org.semanticweb.owl.explanation.impl.laconic;

/**
 * Author: Matthew Horridge<br>
 * The University of Manchester<br>
 * Bio-Health Informatics Group<br>
 * Date: 25/04/2011
 */
public enum ModularityTreatment {

    INPUT_AXIOMS,

    MODULE


}
