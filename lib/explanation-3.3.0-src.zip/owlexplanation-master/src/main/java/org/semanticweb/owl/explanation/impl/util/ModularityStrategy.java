package org.semanticweb.owl.explanation.impl.util;

/**
 * Author: Matthew Horridge<br>
 * The University of Manchester<br>
 * Bio-Health Informatics Group<br>
 * Date: 23/04/2011
 */
public enum ModularityStrategy {

    USE_MODULARITY,

    DONT_USE_MODULARITY
}
