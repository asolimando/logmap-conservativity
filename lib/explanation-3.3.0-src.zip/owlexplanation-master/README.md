owlexplanation
==============

An API and reference implementation for generating justifications for entailments in OWL ontologies
